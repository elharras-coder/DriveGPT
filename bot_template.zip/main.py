import os
import requests
from fastapi import FastAPI, Request

app = FastAPI()

# Базовый URL нашего бэкенда для внутренних запросов
API_URL = "http://127.0.0.1:8000/internal"
# ID проекта будет передаваться через переменные окружения или мы можем его зашить
# (Бот-менеджер на сервере передает его)
PROJECT_ID = int(os.environ.get("PROJECT_ID", 1))

@app.post("/webhook")
async def webhook(request: Request):
    update = await request.json()
    
    if "message" not in update:
        return {"ok": True}
    
    message = update["message"]
    chat_id = message["chat"]["id"]
    text = message.get("text", "")
    from_user = message.get("from", {})
    
    # 1. Регистрируем пользователя через наш бэкенд
    requests.post(f"{API_URL}/users", params={
        "project_id": PROJECT_ID,
        "telegram_id": chat_id,
        "username": from_user.get("username"),
        "first_name": from_user.get("first_name"),
        "last_name": from_user.get("last_name")
    })

    # 2. Логика бота
    if text == "/start":
        bot_response = "Привет! Я бот DriveGPT. Пришли мне фото своего автомобиля, чтобы начать примерку дисков."
        send_message(chat_id, bot_response)
    else:
        # Если это фото
        if "photo" in message:
            # Тут могла бы быть логика сохранения фото
            bot_response = "Красивое авто! Теперь пришли фото диска, который хочешь примерить."
            send_message(chat_id, bot_response)
        else:
            bot_response = "Я пока понимаю только текст и фото. Пришли фото машины!"
            send_message(chat_id, bot_response)

    return {"ok": True}

def send_message(chat_id, text):
    # В реальности тут нужен TOKEN бота, который бэкенд прокидывает в переменные окружения
    TOKEN = os.environ.get("TELEGRAM_TOKEN")
    if TOKEN:
        url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
        requests.post(url, json={"chat_id": chat_id, "text": text})
        
        # Сохраняем наш ответ в базу проекта через бэкенд
        requests.post(f"{API_URL}/messages", json={
            "project_id": PROJECT_ID,
            "telegram_id": str(chat_id),
            "direction": "out",
            "text": text,
            "sent_by": "bot"
        })

if __name__ == "__main__":
    import uvicorn
    # Порт задается бэкендом (обычно 9001, 9002 и т.д.)
    port = int(os.environ.get("PORT", 9001))
    uvicorn.run(app, host="0.0.0.0", port=port)
